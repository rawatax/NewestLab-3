﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab3
{
    public partial class Students : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["accountId"] == null)
                {
                    Response.Redirect("Default.aspx", false);
                }
                else
                {
                    string sqlQuery = "SELECT TeacherID, (FirstName + ' ' + LastName) as NAME from Teacher";

                    SqlConnection sqlConnect = new
                        SqlConnection(ConfigurationManager.ConnectionStrings["Lab3"].ConnectionString);
                    SqlDataAdapter sqlAdapt = new SqlDataAdapter(sqlQuery, sqlConnect);

                    DataTable dataTable = new DataTable();
                    sqlAdapt.Fill(dataTable);
                    teacherDropDown.DataSource = dataTable;
                    teacherDropDown.DataTextField = "NAME";
                    teacherDropDown.DataValueField = "TeacherID";
                    teacherDropDown.DataBind();
                    teacherDropDown.Items.Insert(0, new ListItem("Select", "0"));
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnect = new
                SqlConnection(ConfigurationManager.ConnectionStrings["Lab3"].ConnectionString);

            sqlConnect.Open();

            Int32 lastId = 0;
            string lastIdSql = "SELECT TOP 1 TshirtID FROM Tshirt ORDER BY TshirtID DESC";
            using (SqlCommand cmd = new SqlCommand(lastIdSql, sqlConnect))
            {
                lastId = (Int32)cmd.ExecuteScalar();
                lastId += 1;
            }

            Tshirt newShirt = new Tshirt(lastId, dropShirtSize.SelectedItem.Text, dropShirtColor.SelectedItem.Text);

            string sql = "INSERT INTO Tshirt(TshirtID,Size,Color) VALUES(@param1,@param2,@param3)";

            using (SqlCommand cmd = new SqlCommand(sql, sqlConnect))
            {
                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = newShirt.TshirtID;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar, 50).Value = newShirt.Size;
                cmd.Parameters.Add("@param3", SqlDbType.VarChar, 50).Value = newShirt.Color;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }

            Int32 lastStudentId = 0;
            string lastStudentIdSql = "SELECT TOP 1 StudentId FROM Student ORDER BY StudentId DESC";
            using (SqlCommand cmd = new SqlCommand(lastStudentIdSql, sqlConnect))
            {
                lastStudentId = (Int32)cmd.ExecuteScalar();
                lastStudentId += 1;
            }


            Student newStudent = new Student(lastStudentId, FirstName.Text, LastName.Text, Convert.ToInt32(Age.Text), Notes.Text, Convert.ToInt32(teacherDropDown.SelectedValue), newShirt.TshirtID);

            string dupSql = "SELECT COUNT(1) FROM Student WHERE ";
            dupSql += "FirstName = '" + newStudent.FirstName + "'";
            dupSql += " AND LastName = '" + newStudent.LastName + "'";
            dupSql += " AND Age = " + newStudent.Age.ToString();
            dupSql += " AND TeacherId = " + newStudent.TeacherId.ToString();

            int dupCheck = 0;
            using (SqlCommand cmd = new SqlCommand(dupSql, sqlConnect))
            {
                dupCheck = (Int32)cmd.ExecuteScalar();
            }

            if (dupCheck < 1)
            {
                string studentSql = "INSERT INTO Student(StudentID,FirstName,LastName,Age,Notes,TeacherId,TshirtId) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7)";

                try
                {
                    using (SqlCommand cmd = new SqlCommand(studentSql, sqlConnect))
                    {
                        cmd.Parameters.Add("@param1", SqlDbType.Int).Value = newStudent.StudentId;
                        cmd.Parameters.Add("@param2", SqlDbType.VarChar, 50).Value = newStudent.FirstName;
                        cmd.Parameters.Add("@param3", SqlDbType.VarChar, 50).Value = newStudent.LastName;
                        cmd.Parameters.Add("@param4", SqlDbType.Int).Value = newStudent.Age;
                        cmd.Parameters.Add("@param5", SqlDbType.VarChar, 50).Value = newStudent.Notes;
                        cmd.Parameters.Add("@param6", SqlDbType.Int).Value = newStudent.TeacherId;
                        cmd.Parameters.Add("@param7", SqlDbType.Int).Value = newStudent.TshirtId;
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                    }
                    this.btnClear_Click(sender, e);

                    Errorlabel.Text = "New student added.";
                    Errorlabel.ForeColor = Color.Green;

                }
                catch (Exception ex)
                {
                    Errorlabel.Text = "Could not add Student.";
                    Errorlabel.ForeColor = Color.Red;
                }

            }
            else
            {
                Errorlabel.Text = "Student already exists.";
                Errorlabel.ForeColor = Color.Red;
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            FirstName.Text = "";
            LastName.Text = "";
            Age.Text = "";
            Notes.Text = "";
            dropShirtSize.SelectedIndex = 0;
            dropShirtColor.SelectedIndex = 0;
            teacherDropDown.SelectedIndex = 0;
            Errorlabel.Text = "";
            SuccessLabel.Text = "";
        }

        protected void btnPopulate_Click(object sender, EventArgs e)
        {
            FirstName.Text = "Anu";
            LastName.Text = "Rawat";
            Age.Text = "12";
            Notes.Text = "New Student";
            dropShirtSize.SelectedIndex = 1;
            dropShirtColor.SelectedIndex = 2;
            teacherDropDown.SelectedIndex = 1;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnect = new
                SqlConnection(ConfigurationManager.ConnectionStrings["Lab3"].ConnectionString);

            sqlConnect.Open();

            var searchQuery = searchStudent.Text.Split(' ');

            string sql = "SELECT * FROM Student WHERE";
            sql += " TeacherID = " + Session["accountId"] + " AND";

            foreach (var q in searchQuery)
            {
                if (searchQuery.Count() < 2)
                {
                    sql += " (FirstName LIKE '" + q + "'";
                    sql += " OR LastName LIKE '" + q + "')";
                } else if (searchQuery.FirstOrDefault() == q)
                {
                    sql += " (FirstName LIKE '" + q + "'";
                    sql += " OR LastName LIKE '" + q + "'";
                } else if (searchQuery.LastOrDefault() == q)
                {
                    sql += " OR FirstName LIKE '" + q + "'";
                    sql += " OR LastName LIKE '" + q + "')";
                } else
                {
                    sql += " OR FirstName LIKE '" + q + "'";
                    sql += " OR LastName LIKE '" + q + "'";
                }
            }



            SqlCommand cmd = new SqlCommand(sql, sqlConnect);
            cmd.CommandType = CommandType.Text;

            List<Student> searchResults = new List<Student>();


            using (SqlDataReader rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                {
                    TableCell firstName = new TableCell() { Text = rdr["FirstName"].ToString() };
                    TableCell lastName = new TableCell() { Text = rdr["LastName"].ToString() };
                    TableCell edit = new TableCell();
                    Button button = new Button();
                    button.Text = "EDIT";
                    button.CausesValidation = false;
                    button.UseSubmitBehavior = false;
                    //button.OnClientClick = "";
                    button.PostBackUrl = "EditStudent.aspx?studentID=" + rdr["StudentID"].ToString();
                    button.ID = "btnEdit" + rdr["StudentID"].ToString();
                    edit.Controls.Add(button);

                    TableRow row = new TableRow();
                    row.Cells.Add(firstName);
                    row.Cells.Add(lastName);
                    row.Cells.Add(edit);
                    searchTable.Rows.Add(row);

                }
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            var studentId = btn.CommandArgument.ToString();
            Console.WriteLine(studentId);
        }
    }
}